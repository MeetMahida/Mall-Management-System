# Mall Management system
This project is being developed in django. 
