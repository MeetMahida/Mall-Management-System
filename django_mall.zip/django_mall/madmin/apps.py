from django.apps import AppConfig


class MadminConfig(AppConfig):
    name = 'madmin'
