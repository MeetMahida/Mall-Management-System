from django.contrib import admin
from .models import AdminData, Product
# Register your models here.
admin.site.register(AdminData)
admin.site.register(Product)